</div>

				<!-- footer -->
			
		<div id="footer">
			<center>&copy; All right Reserved. Dhaka University of Engineering and Technology.</center>
		</div>
	</div>
</body>
</html>