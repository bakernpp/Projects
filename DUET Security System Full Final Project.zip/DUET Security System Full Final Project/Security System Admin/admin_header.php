<html>
<head>
	<title>DUET Security System</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/admin_dahsboard.css">
</head>
<body>
				<script src="js/jquery.min.js"></script>
				<script src="js/bootstrap.min.js"></script>


	<div id="wrapper">
		<div id="header">
			<div id="left_header">
				<h1 class="b"><span style="color:#F5A203;">Admin</span> Dashboard</h1>
			</div>
			<div id="right_header">
				<a href="index.php">Logout</a>
			</div>
		</div>

		<?php include ('admin_menu.php');?>

		<div id="main_container">