
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
   <title>CSS MenuMaker</title>
</head>
<body>

<div id='cssmenu'>
  <ul>
      <li><a href='admin_panel_home.php'><span>Dashboard</span></a></li>
      <li><a href='student_signup.php'><span>Student Signup</span></a></li>
      <li><a href='room_insert.php'><span>Insert Room</span></a></li>
      <li><a href='employee_insert.php'><span>Employee SignUp</span></a></li>
      <li><a href='all_entry_information.php'><span>All Entry Information</span></a></li>
   </ul>     
</div>
</body>
<html>
