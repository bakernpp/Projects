<?php include('admin_header.php') ?>
			<center><h2>Welcome to Dashboard !</h2></center>
<?php include('admin_footer.php') ?>		