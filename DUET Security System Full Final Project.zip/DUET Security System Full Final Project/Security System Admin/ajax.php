<?php
$dept = array('CE' => 1,'ME'=>2,'EEE' => 3,'CSE'=>4,'TE' => 5,
		'ARCH'=>6,'IPE' => 7,'F.R KHAN HALL' => 8,'Q.K HALL'=>9,
		'S.M HALL' => 10,'K.N.I HALL'=>11,'S.T.A HALL' => 12,
		'M.C HALL'=>13 );
	$dname='<select id="worksin" name="worksin" class="form-control" >';
	 foreach ($dept as $key => $value) {
	 	   if ($key==$_SESSION['old_input']['worksin']){
	 		 $dname.='<option selected="selected">'.$key.'</option>';
	 	  }
	 	  else
		 	$dname.='<option>'.$key.'</option>';
	 }
		 	$dname.='</select>';
	echo $dname;
}