<?php
 session_start();
  include('admin_header.php');
  include('connection.php');

 $hallList = array(4=>'F.R KHAN', 3=>'Q.K', 2=>'S.M', 1=>'K.N.I', 5=>'S.T.A', 6=>'M.C');

  $_SESSION['old_input']=$_POST;
	if (!isset($_SESSION['old_input']['worksin'])) 
	{
		$_SESSION['old_input']['worksin']=1;
	}									
	$set=0;	
$success='';
if(isset($_POST['submit']))
{
	$datetxt=$_POST['datetxt'];
	$q1=mysql_query("select `user_id`,`main_gate_status`,`entering_time` from user_enter_time_info where `hall_id` IS NULL and `room_id` IS NULL and entering_time LIKE '$datetxt%'");
	$aff=mysql_affected_rows();
	if($aff>0)
	{
		?>
		<style> .cen{text-align: center;}</style>
		<table border="1" cellspacing="0" width="600px" align="center" style="margin:100px 0 100 150;">
										<tr >
											<th class='cen' colspan="3"><h2 style="color:red;">Main Gate Information</h2></th>
										</tr>
										<tr >
											<th class='cen'>User Id</th>
											<th class='cen'>Status</th>
											<th class='cen'>Entering Date and Time</th>
										</tr>
								<?php
									while ($data=mysql_fetch_assoc($q1)) 
									{
								?>
										<tr>
											<td align="center"><?php echo $data['user_id']; ?></td>
											<td align="center"><?php echo $data['main_gate_status']; ?></td>
											<td align="center"><?php echo $data['entering_time']; ?></td>
										</tr>
								<?php	
								}
								?>
								</table>
			<?php				
	}
			else
				echo "No Information Available";






			////Hall 
	$q1=mysql_query("select `user_id`,`hall_id`,`entering_time` from user_enter_time_info where `hall_id` IS NOT NULL and `room_id` IS NULL and entering_time LIKE '$datetxt%'");
	$aff=mysql_affected_rows();
	if($aff>0)
	{
		?>
		<style> .cen{text-align: center;}</style>
		<table border="1" cellspacing="0" width="600px" align="center" style="margin:100px 0 100 150;">
										<tr >
											<th class='cen' colspan="3"><h2 style="color:red;">Hall Entry Information</h2></th>
										</tr>
										<tr >
											<th class='cen'>User Id</th>
											<th class='cen'>Hall Name</th>
											<th class='cen'>Entering Date and Time</th>
										</tr>
								<?php
									while ($data=mysql_fetch_assoc($q1)) 
									{
								?>
										<tr>
											<td align="center"><?php echo $data['user_id']; ?></td>
											<td align="center">
												<?php
												if($data['hall_id']!=null) 
													echo $hallList[$data['hall_id']];
												else 
													echo 0; 
												?>
											</td>
											<td align="center"><?php echo $data['entering_time']; ?></td>
										</tr>
								<?php	
								}
								?>
								</table>
			<?php				
	}
			else
				echo '<center>'."<h2 style='color:red;'>"."No Hall Entry Information Available"."</h2>".'</center>'."<BR />";
			////Hall


			//Room
			$q1=mysql_query("select `user_id`,`room_id`,`entering_time` from user_enter_time_info where `hall_id` IS NULL and `room_id` IS NOT NULL and entering_time LIKE '$datetxt%'");
	$aff=mysql_affected_rows();
	if($aff>0)
	{
		?>
		<style> .cen{text-align: center;}</style>
		<table border="1" cellspacing="0" width="600px" align="center" style="margin:100px 0 100 150;">
										<tr >
											<th class='cen' colspan="3"><h2 style="color:red;">Room Entry Information<h2></th>
										</tr>
										<tr >
											<th class='cen'>User Id</th>
											<th class='cen'>Room No</th>
											<th class='cen'>Entering Date and Time</th>
										</tr>
								<?php
									while ($data=mysql_fetch_assoc($q1)) 
									{
								?>
										<tr>
											<td align="center"><?php echo $data['user_id']; ?></td>
											<td align="center">
												<?php
												if($data['room_id']!=null) 
													echo $data['room_id']; 
												else 
													echo 0;  
													
												?>
											</td>
											<td align="center"><?php echo $data['entering_time']; ?></td>
										</tr>
								<?php	
								}
								?>
								</table>
			<?php				
	}
			else
				echo '<center>'."<h2 style='color:red;'>"."No Room Entry Information Available"."</h2>".'</center>'."<BR />";
			//Room
}
 ?>
<meta charset="UTF-8" />
<style type="text/css">
 select { display:none; }
</style>		
	<legend><span style="color:orange;font-weight:bold;"><center>All Entry Information</center></span></legend>
	<?php
	echo $success;
	?>
	<div class="login">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table border="0" cellspacing="0" width="100%" height='200'>
			<tr>
				<td><label for="fname" class=" control-label">Pick a Date</label></td>
				<td><input type="date" name="datetxt" class="form-control" id="fname"></td>
			</tr>
			<tr>
				<td colspan="2" align="right"><input type="submit" name="submit" value="Show" class="btn btn-success"></td>
			</tr>
		</table>
	</form>
	</div>
<?php include('admin_footer.php') ?>
