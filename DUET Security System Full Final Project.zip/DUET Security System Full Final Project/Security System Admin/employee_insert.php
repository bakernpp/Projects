<?php
 session_start();
  include('admin_header.php');
  include('connection.php');
  $_SESSION['old_input']=$_POST;
	if (!isset($_SESSION['old_input']['worksin'])) 
	{
		$_SESSION['old_input']['worksin']=1;
	}									
	$set=0;	
$success='';
if(isset($_POST['submit']))
{
	$firstname = $_POST["firstname"];
	$lastname = $_POST["lastname"];
	$district=$_POST['district'];
	$street=$_POST['street'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];

	$employeeid=$_POST["employeeid"];
	$emptype=$_POST['emptype'];
	$hall_id=$_POST['hall_id'];
	$dept_id=$_POST['dept_id'];
	
	$select="SELECT `room_id` FROM room_info where `dept_id`='$dept_id'";
	$sql=mysql_query($select);

	if($emptype==2)
		$user_name="Faculty Member";
	else if($emptype==3)
		$user_name="Staff";
	else if($emptype==4) 
		$user_name="Officer";
	else if($emptype==5) 
		$user_name="Guard";
	$q1=mysql_query("insert into user_info values('$employeeid','$user_name','$emptype')");

	$q2="insert into employee_info values('','$firstname','$lastname','$district','$street','$email','$phone','$employeeid','$dept_id')";	
	mysql_query($q2);

	if($hall_id!=0)
	{
		if($emptype==5 || $emptype==2)
		{
			if($emptype==5)
			{
				$q4=mysql_query("insert into hall_permission values('$employeeid','$hall_id','1')");
			}
			else
			{
				$q5=mysql_query("insert into hall_permission values('$employeeid','$hall_id','1')");
				while ($f=mysql_fetch_assoc($sql)) 
				{
						$q5="insert into  room_permission values('$employeeid','".$f['room_id']."','1')"; 
							//echo $q3."<br />";
						mysql_query($q5);
				}
			}
		}
	}
	else
	{
		if($emptype==3 || $emptype==4 || $emptype==5)
		{
			while ($f=mysql_fetch_assoc($sql)) 
			{
						$q6="insert into  room_permission values('$employeeid','".$f['room_id']."','1')"; 
							//echo $q3."<br />";
							mysql_query($q6);
			}
		}
	}

	$aff=mysql_affected_rows();
	if($aff>0)
	{
		$success= '<center>'.'<table width="600" style="border:1px solid #006633;margin-bottom:20px;color:#009900;font-weight:normal;">'.
		'<tr>'.
			'<th height="43" scope="col" style="font-weight:100;">'
		."An Employee  Inserted Successfully.".	
		'</th>'.
		'</tr>'.
		'</table>'.'</center>';
	}
	else
	echo "Data did not added";
}
 ?>
<meta charset="UTF-8" />
<style type="text/css">
 select { display:none; }
</style>		
	<legend><span style="color:orange;font-weight:bold;"><center>Employee Signup Form</center></span></legend>
	<?php
	echo $success;
	?>
	<div class="login">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table border="0" cellspacing="0" width="100%" height='450px'>
			<tr>
				<td><label for="fname" class=" control-label">First Name</label></td>
				<td><input type="text" name="firstname" class="form-control" id="fname"></td>
			</tr>

			<tr>
				<td><label for="lname" class=" control-label">Last Name</label></td>
				<td><input type="text" name="lastname" class="form-control" id="lname"></td>
			</tr>

			<tr>
				<td><label for="empid" class=" control-label">Employee id</label></td>
				<td><input type="text" name="employeeid" class="form-control" id="empid"></td>
			</tr>
			<tr>
				<td><label for="user" class=" control-label">Employee Type :</label></td>
				<td>
					<select  class="form-control" id="user" name="emptype">
						<option value="2">Faculty Member</option>
						<option value="4">Officer</option>
						<option value="3">Staff</option>
						<option value="5">Guard</option>						
					</select>
				</td>
			</tr>
			
			<tr>
				<td><label for="empid" class=" control-label"><input type="radio" name="Rbtn" onclick="show(1)"> Works in Department <br></label></td>
				<td>
					<div id="selectBoxes">
						<select id="SB0" name="dept_id">
							<option value="0">Select Department</option>   
							<option value="1">CE</option> 
							<option value="2">ME</option>
							 <option value="3">EEE</option> 
							 <option value="4">CSE</option> 
							 <option value="5">TE</option> 
							 <option value="6">ARCH</option> 
							 <option value="7">IPE</option> 
							 <option value="8">Others</option> 
						</select>
						
					</div>
				</td>
			</tr>
			<tr>
				<td><label for="empid" class=" control-label"><input type="radio" name="Rbtn" onclick="show1(2)"> Works in Hall <br></label></td>
				<td>
					<div id="selectBoxe">
						<select id="SB1" name="hall_id"> 
							<option value="0">Select Hall</option> 
							<option value="2">S.M</option> 
							<option value="1">K.N.I</option>
							 <option value="3">Q.K</option> 
							 <option value="4">F.R Khan</option> 
							 <option value="5">S.T.A</option> 
							 <option value="6">M.C</option> 
							
						</select>
						
					</div>
				</td>
			</tr>
			
<script type="text/javascript">
function show() {
  var sbox = '';
  var sel = document.getElementById('selectBoxes').getElementsByTagName('select');
  for (var i=0; i<sel.length; i++) { sel[i].style.display = 'none'; }
  for (var i=0; i<arguments.length; i++) {
    sbox = Number(arguments[i])-1;
    document.getElementById('SB'+sbox).style.display = 'block';
  }
}
function show1() {
  var sbox = '';
  var sel = document.getElementById('selectBoxe').getElementsByTagName('select');
  for (var i=0; i<sel.length; i++) { sel[i].style.display = 'none'; }
  for (var i=0; i<arguments.length; i++) {
    sbox = Number(arguments[i])-1;
    document.getElementById('SB'+sbox).style.display = 'block';
  }
}
</script>
			<tr>
				<td><label for="district" class=" control-label">District</label></td>
				<td><input type="text" name="district" class="form-control" id="district"></td>
			</tr>
			<tr>
				<td><label for="street" class=" control-label">Street</label></td>
				<td><input type="text" name="street" class="form-control" id="street"></td>
			</tr>
			<tr>
				<td><label for="phone" class=" control-label">Phone</label></td>
				<td><input type="text" name="phone" class="form-control" id="phone"></td>
			</tr>

			<tr>
				<td><label for="email" class=" control-label">Email</label></td>
				<td><input type="email" name="email" class="form-control" id="email"></td>
			</tr>

			<tr>
				<td colspan="2" align="right"><input type="submit" name="submit" value="Insert" class="btn btn-success"></td>
			</tr>
		</table>
	</form>
	</div>
<?php include('admin_footer.php') ?>
