<?php
session_start();
$message='';

if(isset($_POST['enter_']))
{
  $idtxt=$_POST['idtxt'];
  $passtxt=$_POST['passtxt'];

  if ($idtxt=="helloduet" && $passtxt=="123") 
  {
      
      header("Location:admin_panel_home.php");
      exit;
  }
    else
        $message='Incorrect ID !';
}
?>
<html>
<head>
  <title>
      Admin Login
  </title>
  <link rel="shortcut icon" href="images/1.jpg" type="image/jpg">
  <style type="text/css">
    body
    {
      background-color: #1d1d1d;
      font-family: verdana;
      font-size: 12px;
    }
    div#wrapper
    {
      width: 300px;
      background-color: #fff;
      margin: 0 auto;
      padding:0 auto;
      padding:10 10 10 20;
      margin-top: 200px;
    }
    #input_enter_
    {
      background:none;
      border: 0;
      background-color: #1b9bff;
      padding: 5 10;
      margin-left: 50px;
    }
 h1{color: #6CD6FA; font-family: 'arial';font-size: 20px;font-weight: 100;}
  </style>
</head>
<body>
  <div id="wrapper">
    <h1 style="background-color:#1d1d1d;padding:10;">DUET Security System</h1>
    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post"> 

       <center><h1><span style="color:#1b9bff;">Admin Login </span> </h1></center>

        Username : <input type="text" name="idtxt" value=""  /><br /><br />

        Password : <input type="password" name="passtxt" value=""  /><br /><br />


        <center><span style="color:red;font-weight:bold;"><?php echo $message; ?></span></center>

        <input type="submit" name="enter_" value="Enter" id="input_enter_" />
    </form> 
  </div>
</body>
</html>