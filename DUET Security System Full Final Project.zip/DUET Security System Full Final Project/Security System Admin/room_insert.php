<?php
 session_start();
  include('admin_header.php');
  include('connection.php');
  $_SESSION['old_input']=$_POST;
  $_SESSION['old_input']['err']='';
    $validation=true;
	if (!isset($_SESSION['old_input']['department'])) {
		$_SESSION['old_input']['department']=1;
	}									
												//department list.....
	$dept = array('CE' => 1,'ME'=>2,'EEE' => 3,'CSE'=>4,'TE' => 5,
		'ARCH'=>6,'IPE' => 7 );
	$dname='<select id="department" name="department" class="form-control" >';
	 foreach ($dept as $key => $value) {
	 	   if ($key==$_SESSION['old_input']['department']){
	 		 $dname.='<option selected="selected">'.$key.'</option>';
	 	  }
	 	  else
		 	$dname.='<option>'.$key.'</option>';
	 }
		 	$dname.='</select>';

											//end of department list

 //$d=$dept[$_POST['department']];
 //echo $d;



		 	$success='';

if(isset($_POST['submit']))
{
	$roomid = $_POST["roomid"];
	$roomname = $_POST["roomname"];
	$location=$_POST['location'];
	$department=$dept[$_POST['department']];

	  if (empty($_SESSION['old_input']['roomid'])) {
	  		$_SESSION['old_input']['err']="Field is Empty";
	  		$validation=false;
	  }

	  if (!is_numeric($roomid) && !empty($roomid)) {
	  		$_SESSION['old_input']['err']="Room ID must be Numeric.";
	  		$validation=false;
	  }


	if ($validation==true)
	{
		$sel="insert into room_info
								values('$roomid','$roomname','$location','$department')";	
		$q=mysql_query($sel);
		
		$aff=mysql_affected_rows();
		if($aff>0)
		{
			$success= '<center>'.'<table width="600" style="border:1px solid #006633;margin-bottom:20px;color:#009900;font-weight:normal;">'.
			'<tr>'.
				'<th height="43" scope="col" style="font-weight:100;">'
			."Room Inserted Successfully.".	
			'</th>'.
			'</tr>'.
			'</table>'.'</center>';
		}
		else
		echo "Data did not added";
	}
}

 ?>


			
	<legend><span style="color:red;font-weight:bold;"><center>Insert Room for Department</center></span></legend>
	
	<div class="login">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table border="0" cellspacing="0" width="100%" height='240px'>

			<?php echo $success;?>
			<tr>
				<td><label for="stdid" class=" control-label">Room id</label></td>
				<td><input type="text" name="roomid" class="form-control" id="stdid"
					 value="<?php echo(!empty($_SESSION['old_input']['roomid'])) ? $_SESSION['old_input']['roomid'] : '' ; ?>"></td>
							
			</tr>
				<tr>
					<td colspan='2' align='center'>
							<?php if (isset($_SESSION['old_input']['err'])) {
								if (!empty($_SESSION['old_input']['err'])) {
								
							 ?>
							<span style="color: red; font-weight: bold;"><?php echo $_SESSION['old_input']['err']; ?></span>
							<?php 
							}
							}
							?>
					</td>
				</tr>
			

			<tr>
				<td><label for="roomname" class=" control-label">Room Name</label></td>
				<td><input type="text" name="roomname" class="form-control" id="roomname"></td>
			</tr>

			<tr>
				<td><label for="location" class=" control-label">Location</label></td>
				<td><input type="text" name="location" class="form-control" id="location"></td>
			</tr>

			<tr>
				<td><label for="department" class=" control-label">For Department of </label></td>
				<td><?php echo $dname; ?></td>
			</tr>

			<tr>
				<td colspan="2" align="right"><input type="submit" name="submit" value="Insert Room" class="btn btn-success"></td>
			</tr>
		</table>
	</form>

	</div>
		
<?php include('admin_footer.php') ?>