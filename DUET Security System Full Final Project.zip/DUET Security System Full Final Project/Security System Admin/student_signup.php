<?php
 session_start();
 include('connection.php');
  include('admin_header.php');
  $_SESSION['old_input']=$_POST;
  $_SESSION['old_input']['err']='';
  $validation=true;


	if (!isset($_SESSION['old_input']['department'])) {
		$_SESSION['old_input']['department']=1;
	}									
												//department list.....
	$dept = array('CE' => 1,'ME'=>2,'EEE' => 3,'CSE'=>4,'TE' => 5,
		'ARCH'=>6,'IPE' => 7 );
	$dname='<select id="department" name="department" class="form-control" >';
	 foreach ($dept as $key => $value) {
	 	   if ($key==$_SESSION['old_input']['department']){
	 		 $dname.='<option selected="selected">'.$key.'</option>';
	 	  }
	 	  else
		 	$dname.='<option>'.$key.'</option>';
	 }
		 	$dname.='</select>';

											//end of department list

		 									////Start Hall list

if (!isset($_SESSION['old_input']['hallname'])) {
		$_SESSION['old_input']['hallname']=4;
	}									
						
	$hallList = array('F.R KHAN HALL' => 4,'Q.K HALL'=>3,
		'S.M HALL' => 2,'K.N.I HALL'=>1,'S.T.A HALL' => 5,
		'M.C HALL'=>6 );
	$hall='<select id="hallname" name="hallname" class="form-control" >';
	 foreach ($hallList as $key => $value) {
	 	   if ($key==$_SESSION['old_input']['hallname']){
	 		 $hall.='<option selected="selected">'.$key.'</option>';
	 	  }
	 	  else
		 	$hall.='<option>'.$key.'</option>';
	 }
		 	$hall.='</select>';


		 	////end of hall list

$success='';

if(isset($_POST['submit']))
{
	$studentid = $_POST["studentid"];
	$firstname = $_POST["firstname"];
	$lastname = $_POST["lastname"];
	$district = $_POST["district"];
	$street = $_POST["street"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$email = $_POST["email"];
	$hallname=$hallList[$_POST['hallname']];
	$department=$dept[$_POST['department']];

  if (empty($_SESSION['old_input']['studentid'])) {
  		$_SESSION['old_input']['err']="Field is Empty";
  		$validation=false;
  }

  if (!is_numeric($studentid) && !empty($studentid)) {
  		$_SESSION['old_input']['err']="Data must be Numeric.";
  		$validation=false;
  }


	if ($validation==true)
	{
		$q1=mysql_query("insert into user_info values('$studentid','Student','1')");
		
		$sel="insert into student_info values('','$firstname','$lastname','$district','$street','$email','$phone','$studentid','$department')";	
		$q=mysql_query($sel);
		
		$q2=mysql_query("insert into hall_permission values('$studentid','$hallname','1')");
		
		$select="SELECT `room_id` FROM room_info where `dept_id`='$department'";
		$sql=mysql_query($select);
		$a=mysql_affected_rows();
		if($a>0)
		{
			//echo "OK ";
			while ($f=mysql_fetch_assoc($sql)) 
			{
					$q3="insert into  room_permission values('$studentid','".$f['room_id']."','1')"; 
						//echo $q3."<br />";
						mysql_query($q3);
			}
		}
		$aff=mysql_affected_rows();
		if($aff>0)
		{
			$success= '<center>'.'<table width="600" style="border:1px solid #006633;margin-bottom:20px;color:#009900;font-weight:normal;">'.
			'<tr>'.
				'<th height="43" scope="col" style="font-weight:100;">'
			."Data Inserted Successfully.".	
			'</th>'.
			'</tr>'.
			'</table>'.'</center>';
		}
		else
		echo "Data did not added";
}
}



 //$d=$dept[$_POST['department']];
 //echo $d;
 ?>

			
	<legend><span style="color:orange;font-weight:bold;"><center>Student Signup Form</center></span></legend>
	<?php echo $success;?>
	<div class="login">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table border="0" cellspacing="0" width="100%" height='400px'>
			<tr>
				<td><label for="fname" class=" control-label">First Name</label></td>
				<td><input type="text" name="firstname" class="form-control" id="fname"></td>
			</tr>

			<tr>
				<td><label for="lname" class=" control-label">Last Name</label></td>
				<td><input type="text" name="lastname" class="form-control" id="lname"></td>
			</tr>

			<tr>
				<td><label for="stdid" class=" control-label">Student id</label></td>
				<td><input type="text" name="studentid" class="form-control" id="stdid"
					 value="<?php echo(!empty($_SESSION['old_input']['studentid'])) ? $_SESSION['old_input']['studentid'] : '' ; ?>"></td>
							
			</tr>
				<tr><td colspan='2' align='center'>
							<?php if (isset($_SESSION['old_input']['err'])) {
								if (!empty($_SESSION['old_input']['err'])) {
								
							 ?>
							<span style="color: red; font-weight: bold;"><?php echo $_SESSION['old_input']['err']; ?></span>
							<?php 
							}
							}
							?>
					</td><tr>

			<tr>
				<td><label for="department" class=" control-label">Department</label></td>
				<td><?php echo $dname; ?></td>
			</tr>
			<tr>
				<td><label for="hallname" class=" control-label">Hall Name</label></td>
				<td><?php echo $hall; ?></td>
			</tr>
			<tr>
				<td><label for="district" class=" control-label">District</label></td>
				<td><input type="text" name="district" class="form-control" id="district"></td>
			</tr>
			<tr>
				<td><label for="street" class=" control-label">Street</label></td>
				<td><input type="text" name="street" class="form-control" id="street"></td>
			</tr>


			<tr>
				<td><label for="phone" class=" control-label">Phone</label></td>
				<td><input type="text" name="phone" class="form-control" id="phone"></td>
			</tr>

			<tr>
				<td><label for="email" class=" control-label">Email</label></td>
				<td><input type="email" name="email" class="form-control" id="email"></td>
			</tr>

			<tr>
				<td colspan="2" align="right"><input type="submit" name="submit" value="Submit" class="btn btn-success"></td>
			</tr>
		</table>
	</form>

	</div>
		
<?php include('admin_footer.php');
	unset($_SESSION['old_input']);
 ?>