<?php
 session_start();
  include('admin_header.php');
  $_SESSION['old_input']=$_POST;
	if (!isset($_SESSION['old_input']['department'])) {
		$_SESSION['old_input']['department']=1;
	}									
												//department list.....
	$dept = array('CE' => 1,'ME'=>2,'EEE' => 3,'CSE'=>4,'TE' => 5,
		'ARCH'=>6,'IPE' => 7 );
	$dname='<select id="department" name="department" class="form-control" >';
	 foreach ($dept as $key => $value) {
	 	   if ($key==$_SESSION['old_input']['department']){
	 		 $dname.='<option selected="selected">'.$key.'</option>';
	 	  }
	 	  else
		 	$dname.='<option>'.$key.'</option>';
	 }
		 	$dname.='</select>';

											//end of department list

 //$d=$dept[$_POST['department']];
 //echo $d;
 ?>

			
	<legend><span style="color:red;font-weight:bold;"><center>Teacher Signup Form</center></span></legend>
	
	<div class="login">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table border="0" cellspacing="0" width="100%" height='400px'>
			<tr>
				<td><label for="fname" class=" control-label">First Name</label></td>
				<td><input type="text" name="firstname" class="form-control" id="fname"></td>
			</tr>

			<tr>
				<td><label for="lname" class=" control-label">Last Name</label></td>
				<td><input type="text" name="lastname" class="form-control" id="lname"></td>
			</tr>

			<tr>
				<td><label for="tecid" class=" control-label">Teacher id</label></td>
				<td><input type="text" name="teacherid" class="form-control" id="tecid"></td>
			</tr>

			<tr>
				<td><label for="department" class=" control-label">Department</label></td>
				<td><?php echo $dname; ?></td>
			</tr>

			<tr>
				<td><label for="district" class=" control-label">District</label></td>
				<td><input type="text" name="district" class="form-control" id="district"></td>
			</tr>

			<tr>
				<td><label for="phone" class=" control-label">Phone</label></td>
				<td><input type="text" name="phone" class="form-control" id="phone"></td>
			</tr>

			<tr>
				<td><label for="email" class=" control-label">Email</label></td>
				<td><input type="email" name="email" class="form-control" id="email"></td>
			</tr>

			<tr>
				<td colspan="2" align="right"><input type="submit" name="submit" value="Insert" class="btn btn-success"></td>
			</tr>
		</table>
	</form>

	</div>
		
<?php include('admin_footer.php') ?>