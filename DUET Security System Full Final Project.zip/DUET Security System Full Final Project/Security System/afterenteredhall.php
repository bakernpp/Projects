<?php 
	session_start();
	include('connection.php');
	$message='';
	$id=$_SESSION['id'];
	$type=$_SESSION['type'];
	
	$hallid=$_GET['hallid'];
 	$hall_name=$_GET['hall_name'];
	
	$q1=mysql_query("select * from hall_permission where `user_id`='$id' and `hall_id`='$hallid'");
	$aff=mysql_affected_rows();
	if($aff>0)
	{
		 $date = date('Y-m-d H:i:s');
     	 $q2=mysql_query("insert into user_enter_time_info (`user_id`,`hall_id`,`main_gate_status`,`entering_time`) values('$id','$hallid','1','$date')");
     	 $message='Welcome to '.$hall_name.' HALL';
	}
	else
		$message='You are not allowed to enter '.$hall_name.' HALL';

 ?>

 <html>
 <head>
 	<title>DUET SECURITY SYSTEM</title>
 </head>
 	<style>
 	.p{margin: 0px;padding: 0px;}
 			.message{width: 500px;height: 100px; padding: 0 auto;margin: 0 auto;
 				font-size: 30px;color: orange;font-weight: bold; border: 2px solid red;text-align: center; }
 			.msg{padding-top: 50px;}
 	</style>
 <body>
 				<br><br><br>
 			<div class="message"><p msg><?php echo $message; ?></p>
 				<BR />
 				<button><a href="index.php"> BACK </a></button>
 			</div>
 </body>
 </html>