<?php 
  session_start();
  include('connection.php');
  $message='';
  $id=$_SESSION['id'];
  $type=$_SESSION['type'];

  $attention='';
  $hallid=$_GET['hallidpassing'];




  if($hallid==1)
    $hall_name="K.N.I";

  else if($hallid==2)
    $hall_name="S.M";
  
  else if($hallid==3)
    $hall_name="Q.K";
  
  else if($hallid==4)
    $hall_name="F.R Khan";

  else if($hallid==5)
    $hall_name="S.T.A";
  
  else if($hallid==6)
    $hall_name="M.C";




if(isset($_GET['enter_']))
{
  $id_txt=$_GET['id_txt'];
  $hidden_hall_name=$_GET['hidden_hall_name'];
  $hall_name=$_GET['hidden_hall_name'];
  $hallid=$_GET['hidden_hall_id'];

  if($id_txt!=$id)
  {
    $attention="You have entered a Duplicate ID !";
    $hall_name=$_GET['hidden_hall_name'];
  }
  else
  {
    //header("Location:afterenteredhall.php?hallid=$hallid & hall_name=$hidden_hall_name");
     header("Location:afterenteredhall.php?hallid=$hallid & hall_name=$hidden_hall_name");
  }
}
?>
<html>
<head>
  <title>
       Hall Entrance
  </title>
  <link rel="shortcut icon" href="images/1.jpg" type="image/jpg">
  <style type="text/css">
    body
    {
      background-color: #1d1d1d;
      font-family: verdana;
      font-size: 12px;
    }
    div#wrapper
    {
      width: 300px;
      background-color: #fff;
      margin: 0 auto;
      padding:0 auto;
      padding:10 10 10 20;
      margin-top: 200px;
      
      border-left: 10px  solid #1b9bff;
    }
    #input_enter_
    {
      background:none;
      border: 0;
      background-color: #1b9bff;
      padding: 5 10;
      margin-left: 50px;
    }
 h1{color: #6CD6FA; font-family: 'arial';font-size: 20px;font-weight: 100;}
  </style>
</head>
<body>
  <div id="wrapper">
    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="get">  
       <center><h1><span style="color:#1b9bff;"><?php echo $hall_name; ?> HALL Gate Entrance</span> </h1></center>
       


        Enter Your ID : <input type="text" name="id_txt" value=""  /><br /><br />
       
       <input type="hidden" name="hidden_hall_name" value="<?php echo $hall_name;?>">
        <input type="hidden" name="hidden_hall_id" value="<?php echo $hallid;?>">
       
        <center><span style="color:red;font-weight:bold;"><?php echo $attention; ?></span></center>
       

        <input type="submit" name="enter_" value="Enter" id="input_enter_" /><a href="index.php">Back</a>
   
      <input type="hidden" name="hallidpassing" value="<?php echo $hallid;?>">
    </form>
  </div>
</body>
</html>