<?php 
	session_start();
	include('connection.php');
	$message='';
	$id=$_SESSION['id'];
	$type=$_SESSION['type'];

	$hidden_txt=$_GET['idd'];
	$dept_id_pass=$_GET['dept_id_pass'];

	$q1=mysql_query("select * from room_permission where `user_id`='$id' and `room_id`='$hidden_txt'");
	$aff=mysql_affected_rows();
	if($aff>>0)
	{
		 $date = date('Y-m-d H:i:s');
     	 $q2=mysql_query("insert into user_enter_time_info (`user_id`,`room_id`,`main_gate_status`,`entering_time`) values('$id','$hidden_txt','1','$date')");
     	 $message='Welcome to Room No '.$hidden_txt;
	}
	else
		$message='You are not allowed to enter Room No '.$hidden_txt;

 ?>
 <html>
 <head>
 	<title>DUET SECURITY SYSTEM</title>
 </head>
 	<style>
 	.p{margin: 0px;padding: 0px;}
 			.message{width: 500px;height: 100px; padding: 0 auto;margin: 0 auto;
 				font-size: 30px;color: orange;font-weight: bold; border: 2px solid red;text-align: center; }
 			.msg{padding-top: 50px;}
 	</style>
 <body>
 				<br><br><br>
 			<div class="message"><p msg><?php echo $message; ?></p>
 				<button><a href="index.php"> BACK</a></button>
 			</div>
 </body>
 </html>