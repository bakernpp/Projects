<?php
$message='';
?>
<html>
<head>
	<title>DUET Security System</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div id="left_header">
				<h1><span style="color:#1b9bff;">DUET</span> Security System</h1>
			</div>
			<div id="right_header">
				<a href="maingate.php">Logout</a>
			</div>
		</div>

		<?php include ('menu.php');?>
		<div id="main_container">

			<center><b><?php echo $message;?></b></center>
			<?php 
				session_start();
				include('connection.php');
				$message='';
				$id=$_SESSION['id'];
				$type=$_SESSION['type'];

				$select="SELECT `room_id`,`name`,`location` FROM room_info where  `dept_id`='3'";
				//echo $select;
				$sql=mysql_query($select);
				if (mysql_affected_rows()) {
			?>
						<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
							<table border="1" cellspacing="0" width="580px" align="center" style="margin:100px 0 100 150;">
								<tr>
									<th>Room No</th>
									<th>Room Name</th>
									<th>Location</th>
									<th>Action</th>
								</tr>
						<?php
						while ($data=mysql_fetch_assoc($sql)) 
						{
						?>
								<tr>
									<td><?php echo $data['room_id']; ?></td>
									<td><?php echo $data['name']; ?></td>
									<td><?php echo $data['location']; ?></td>
									<td>
										<a href="dept_enter.php?idd=<?php echo $data['room_id']; ?> & dept_id_pass=3">Enter</a>
									</td>
								</tr>
				<?php	
				}
				?>
							</table>
						</form>
				<?php
					}
		 		?>
				
		</div>
		<div id="footer">
			<center>&copy; All right Reserved. Dhaka University of Engineering and Technology.</center>
		</div>
	</div>
</body>
</html>