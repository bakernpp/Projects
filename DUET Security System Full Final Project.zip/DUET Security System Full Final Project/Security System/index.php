<?php
session_start();
$id=$_SESSION['id'];
$type=$_SESSION['type'];
echo $id." ".$type;

?>

<html>
<head>
	<title>DUET Security System</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div id="left_header">
				<h1><span style="color:#1b9bff;">DUET</span> Security System</h1>
			</div>
			<div id="right_header">
				<a href="maingate.php">Logout</a>
			</div>
		</div>

		<?php include ('menu.php');?>
		<div id="main_container">
			
				<br /><br />
			<div id="left_container">
				<h2>Class Room Accesibility</h2>
				<img src="images/1.jpg" width="250" height="150" class="img_work" />
				<p>
					If you are a Student or a teacher , you can enter into the class room of your department.
					For example : If you are a student of Computer Science and Engineering Department, you can enter only Computer Science and Engineering Department.
					A teacher can also enter in his classroom.
				</p>

			</div>
			<div id="middle_container">
				<h2>Hall Entraince with ID Card</h2>
				<img src="images/2.jpg" width="250" height="150" class="img_work"/>	
				<p>
					You can enter into your hall if you show id. Other external person are not allowable into the hall.
					A teacher who is a provost of a hall can entire in his hall with showing his ID card.
				</p>
			</div>
			<div id="right_container">
				<h2>Department Accesibility</h2>
				<img src="images/3.jpg" width="250" height="150" class="img_work" />
				<p>
					Department teachers,students and also the staffs of a department can also enter into the department offices and class room.
					Department buildings are separated.
				</p>
			</div>
		</div>
		<div id="footer">
			<center>&copy; All right Reserved. Dhaka University of Engineering and Technology.</center>
		</div>
	</div>
</body>
</html>