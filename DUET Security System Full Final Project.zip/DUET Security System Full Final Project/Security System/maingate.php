<?php
session_start();
unset($_SESSION['type']);
unset($_SESSION['id']);
unset($_SESSION['gate_status']);
$message='';
include("connection.php");

if(isset($_POST['enter_']))
{
  $idtxt=$_POST['idtxt'];
  $select="(SELECT `user_id`,`user_type` FROM user_info WHERE `user_id`='".$idtxt."')";
  echo $select;
  
  $query=mysql_query($select);
  
  $aff=mysql_affected_rows();
  if ($aff>0) 
  {
      $data=mysql_fetch_assoc($query);
      $_SESSION['type']=$data['user_type'];
      $_SESSION['id']=$data['user_id'];
      $_SESSION['gate_status']=1;
      $date = date('Y-m-d H:i:s');
      $q1=mysql_query("insert into user_enter_time_info (`user_id`,`main_gate_status`,`entering_time`) values('$idtxt','1','$date')");
      header("Location:index.php");
      exit;
  }
    else
        $message='Incorrect ID !';
}
?>
<html>
<head>
  <title>
      Main Gate

  </title>
  <link rel="shortcut icon" href="images/1.jpg" type="image/jpg">
  <style type="text/css">
    body
    {
      background-color: #1d1d1d;
      font-family: verdana;
      font-size: 12px;
    }
    div#wrapper
    {
      width: 300px;
      background-color: #fff;
      margin: 0 auto;
      padding:0 auto;
      padding:10 10 10 20;
      margin-top: 200px;
      
      border-left: 10px  solid #1b9bff;
    }
    #input_enter_
    {
      background:none;
      border: 0;
      background-color: #1b9bff;
      padding: 5 10;
      margin-left: 50px;
    }
 h1{color: #6CD6FA; font-family: 'arial';font-size: 20px;font-weight: 100;}
  </style>
</head>
<body>
  <div id="wrapper">
    <h1 style="background-color:#1d1d1d;padding:10;">DUET Security System</h1>
    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">  
       <center><h1><span style="color:#1b9bff;">Main Gate Entrance</span> </h1></center>
        Enter Your ID : <input type="text" name="idtxt" value=""  /><br /><br />
        <center><span style="color:red;font-weight:bold;"><?php echo $message; ?></span></center>
        <input type="submit" name="enter_" value="Enter" id="input_enter_" />
    </form> 
  </div>
</body>
</html>