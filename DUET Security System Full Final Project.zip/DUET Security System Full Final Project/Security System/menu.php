
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
   <title>CSS MenuMaker</title>
</head>
<body>
<div id='cssmenu'>
<ul>
   <li class="active"><a href='index.php'><span>Home</span></a></li>
   <li class='has-sub'><a href='#'><span>Hall</span></a>
      <ul>
         <li><a href='all_hall_entrance.php?hallidpassing=1'><span>K.N.I Hall</span></a></li>
         <li><a href='all_hall_entrance.php?hallidpassing=2'><span>S.M Hall</span></a></li>
         <li><a href='all_hall_entrance.php?hallidpassing=3'><span>Q.K Hall</span></a></li>
         <li><a href='all_hall_entrance.php?hallidpassing=4'><span>F.R Khan Hall</span></a></li>
         <li><a href='all_hall_entrance.php?hallidpassing=5'><span>S.T.A Hall</span></a></li>
         <li><a href='all_hall_entrance.php?hallidpassing=6'><span>M.C. Hall</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>Classroom</span></a>
      <ul>
         <li><a href='cse.php'><span>Department of CSE</span></a></li>
         <li><a href='ce.php'><span>Department of CE</span></a></li>
         <li><a href='eee.php'><span>Department of EEE</span></a></li>
         <li><a href='me.php'><span>Department of ME</span></a></li>
         <li><a href='te.php'><span>Department of TE</span></a></li>
         <li><a href='ipe.php'><span>Department of IPE</span></a></li>
         <li><a href='arch.php'><span>Department of ARCH</span></a></li>
      </ul>
   </li>
   <li class='last'><a href='#'><span>Contact</span></a></li>
</ul>
</div>

</body>
<html>
