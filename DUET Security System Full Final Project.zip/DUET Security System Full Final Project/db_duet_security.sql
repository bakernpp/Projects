-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 30, 2015 at 02:15 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_duet_security`
--

-- --------------------------------------------------------

--
-- Table structure for table `department_info`
--

CREATE TABLE IF NOT EXISTS `department_info` (
  `dept_id` int(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `location` varchar(40) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_info`
--

INSERT INTO `department_info` (`dept_id`, `name`, `location`) VALUES
(1, 'CE', 'Old Academic Building'),
(2, 'ME', 'Old Academic Building'),
(3, 'EEE', 'Old Academic Building'),
(4, 'CSE', 'Old Academic Building'),
(5, 'TE', 'New Academic Building'),
(6, 'ARCH', 'New Academic Building'),
(7, 'IPE', 'New Academic Building'),
(8, 'Others', 'Hall');

-- --------------------------------------------------------

--
-- Table structure for table `employee_info`
--

CREATE TABLE IF NOT EXISTS `employee_info` (
  `employee_id` int(40) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(40) NOT NULL,
  `l_name` varchar(40) NOT NULL,
  `district` varchar(40) NOT NULL,
  `street` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `user_id` int(40) NOT NULL,
  `dept_id` int(40) NOT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `user_id` (`user_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `employee_info`
--

INSERT INTO `employee_info` (`employee_id`, `f_name`, `l_name`, `district`, `street`, `email`, `phone`, `user_id`, `dept_id`) VALUES
(4, 'Habib', 'Ullah', 'f', 'f', 'f@yahoo.com', 'f', 121212, 8),
(5, 'Nazrul', 'Islam', 'b', 'b', 'h@gmail.com', 'b', 39455, 1),
(6, 'Amran', 'Hosseain', 'g', 'g', 'H@gmail.com', 'g', 123456, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hall_info`
--

CREATE TABLE IF NOT EXISTS `hall_info` (
  `hall_id` int(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `location` varchar(40) NOT NULL,
  PRIMARY KEY (`hall_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hall_info`
--

INSERT INTO `hall_info` (`hall_id`, `name`, `location`) VALUES
(1, 'K.N.I', 'North'),
(2, 'S.M', 'South'),
(3, 'Q.K', 'North-east'),
(4, 'F.R KHAN', 'North-west'),
(5, 'S.T.A', 'West'),
(6, 'M.C', 'South');

-- --------------------------------------------------------

--
-- Table structure for table `hall_permission`
--

CREATE TABLE IF NOT EXISTS `hall_permission` (
  `user_id` int(40) NOT NULL,
  `hall_id` int(40) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `hall_id` (`hall_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hall_permission`
--

INSERT INTO `hall_permission` (`user_id`, `hall_id`) VALUES
(124058, 1),
(123048, 1),
(121212, 1),
(123456, 4);

-- --------------------------------------------------------

--
-- Table structure for table `room_info`
--

CREATE TABLE IF NOT EXISTS `room_info` (
  `room_id` int(40) NOT NULL,
  `name` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `dept_id` int(40) NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_info`
--

INSERT INTO `room_info` (`room_id`, `name`, `location`, `dept_id`) VALUES
(101, 'Wood Lab', 'New Academic Building', 1),
(102, 'Classroom', 'New Academic Building', 1),
(103, 'Classroom', 'Old Building', 1),
(418, 'Class Room', 'New Building', 4),
(504, 'Thesis Lab', 'Library Building', 4),
(2002, 'Class Room', 'New Building', 2),
(2003, 'Class Room', 'New Building', 2),
(2004, 'Class Room', 'New Building', 2),
(2005, 'Class Room', 'New Building', 2),
(2006, 'Class Room', 'New Building', 6),
(2007, 'Class Room', 'New Building', 6),
(2008, 'Class Room', 'New Building', 4),
(2010, 'Class Room', 'New Building', 6),
(2011, 'Class Room', 'New Building', 6),
(3001, 'Class Room', 'New Building', 3),
(3002, 'Class Room', 'New Building', 3),
(3003, 'Class Room', 'New Building', 3),
(3004, 'Class Room', 'New Building', 3),
(3031, 'Class Room', 'New Buidling', 4),
(4001, 'Class Room', 'New Building', 5),
(4002, 'Class Room', 'New Building', 5),
(4003, 'Class Room', 'New Building', 5),
(4004, 'Class Room', 'New Building', 5);

-- --------------------------------------------------------

--
-- Table structure for table `room_permission`
--

CREATE TABLE IF NOT EXISTS `room_permission` (
  `user_id` int(40) NOT NULL,
  `room_id` int(40) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_permission`
--

INSERT INTO `room_permission` (`user_id`, `room_id`) VALUES
(123048, 101),
(123048, 102),
(123048, 103),
(39455, 101),
(39455, 102),
(39455, 103),
(123456, 101),
(123456, 102),
(123456, 103);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE IF NOT EXISTS `student_info` (
  `student_id` int(40) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `user_id` int(40) NOT NULL,
  `dept_id` int(40) NOT NULL,
  PRIMARY KEY (`student_id`),
  KEY `user_id` (`user_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `f_name`, `l_name`, `district`, `street`, `email`, `phone`, `user_id`, `dept_id`) VALUES
(1, 'Baker', 'Hossen', 'N', 'N', 'N@gmail.com', 'N', 124058, 4),
(5, 'f', 'f', 'g', 'g', 'g@gmail.ocm', 'g', 123048, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_enter_time_info`
--

CREATE TABLE IF NOT EXISTS `user_enter_time_info` (
  `user_id` int(40) NOT NULL,
  `hall_id` int(40) DEFAULT NULL,
  `room_id` int(40) DEFAULT NULL,
  `main_gate_status` int(10) NOT NULL,
  `entering_time` datetime NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `hall_id` (`hall_id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_enter_time_info`
--

INSERT INTO `user_enter_time_info` (`user_id`, `hall_id`, `room_id`, `main_gate_status`, `entering_time`) VALUES
(121212, NULL, NULL, 1, '2015-11-30 11:17:00'),
(121212, NULL, NULL, 1, '2015-11-30 11:33:38'),
(121212, 1, NULL, 1, '2015-11-30 13:08:30'),
(121212, 1, NULL, 1, '2015-11-30 13:09:10'),
(121212, 1, NULL, 1, '2015-11-30 13:09:25'),
(121212, 1, NULL, 1, '2015-11-30 13:10:07'),
(121212, 1, NULL, 1, '2015-11-30 13:15:59'),
(124058, NULL, NULL, 1, '2015-11-30 13:16:59'),
(124058, 1, NULL, 1, '2015-11-30 13:17:01'),
(123456, NULL, NULL, 1, '2015-11-30 13:17:51'),
(39455, NULL, NULL, 1, '2015-11-30 13:19:47'),
(121212, NULL, NULL, 1, '2015-11-30 13:23:50'),
(121212, 1, NULL, 1, '2015-11-30 13:52:33'),
(121212, NULL, NULL, 1, '2015-11-30 13:55:10'),
(123048, NULL, NULL, 1, '2015-11-30 13:58:21'),
(123048, NULL, 101, 1, '2015-11-30 13:58:44'),
(123048, NULL, 102, 1, '2015-11-30 13:59:59'),
(123048, NULL, 103, 1, '2015-11-30 14:00:40'),
(123048, NULL, 101, 1, '2015-11-30 14:06:33'),
(123048, NULL, 103, 1, '2015-11-30 14:07:01'),
(121212, NULL, NULL, 1, '2015-11-30 14:07:59'),
(121212, 1, NULL, 1, '2015-11-30 14:08:47');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(40) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `user_type` int(40) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `user_name`, `user_type`) VALUES
(39455, 'Staff', 3),
(121212, 'Guard', 5),
(123048, 'Student', 1),
(123456, 'Faculty Member', 2),
(124058, 'Student', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee_info`
--
ALTER TABLE `employee_info`
  ADD CONSTRAINT `employee_info_ibfk_2` FOREIGN KEY (`dept_id`) REFERENCES `department_info` (`dept_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `hall_permission`
--
ALTER TABLE `hall_permission`
  ADD CONSTRAINT `hall_permission_ibfk_2` FOREIGN KEY (`hall_id`) REFERENCES `hall_info` (`hall_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hall_permission_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `room_info`
--
ALTER TABLE `room_info`
  ADD CONSTRAINT `room_info_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department_info` (`dept_id`) ON DELETE CASCADE;

--
-- Constraints for table `room_permission`
--
ALTER TABLE `room_permission`
  ADD CONSTRAINT `room_permission_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `room_info` (`room_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `room_permission_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_info`
--
ALTER TABLE `student_info`
  ADD CONSTRAINT `student_info_ibfk_2` FOREIGN KEY (`dept_id`) REFERENCES `department_info` (`dept_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_enter_time_info`
--
ALTER TABLE `user_enter_time_info`
  ADD CONSTRAINT `user_enter_time_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_enter_time_info_ibfk_2` FOREIGN KEY (`hall_id`) REFERENCES `hall_info` (`hall_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_enter_time_info_ibfk_3` FOREIGN KEY (`room_id`) REFERENCES `room_info` (`room_id`) ON DELETE CASCADE;
